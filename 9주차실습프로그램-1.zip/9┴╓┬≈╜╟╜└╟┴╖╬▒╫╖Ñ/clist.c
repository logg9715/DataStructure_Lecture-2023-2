#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

typedef struct cnode* cList;
struct cnode {
    char cid[10];
    int cpart;
    int wn;
    cList next;
};

int waiting_sum(cList ptr) {
    int sum = 0;
   
    while (ptr != NULL) {
        sum += ptr->wn;
        ptr = ptr->next;
    }
    return sum;
}

main()
{
    cList inode, before=NULL, ptr=NULL, head;
    int i, n;

    printf("�� �ݼ����� ������ ���� = ");
    scanf("%d", &n);
    head = (cList)malloc(sizeof(struct cnode));
    scanf("%s %d %d", head->cid, &(head->cpart), &(head->wn));
    head->next = NULL;
   
    for (i = 1; i < n; i++) {
        inode = (cList)malloc(sizeof(struct cnode));
        scanf("%s %d %d", inode->cid, &(inode->cpart), &(inode->wn));
        ptr = head;
   
        while (ptr != NULL) {
            before = ptr;
            ptr = ptr->next;
        }
        before->next = inode;
        inode->next = NULL;
    }
    
    printf("��ü %d���� ��� ���Դϴ�\n", waiting_sum(head));
}